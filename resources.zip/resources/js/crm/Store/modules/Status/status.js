import {axiosGet} from "../../../Helpers/AxiosHelper";

const state = {
    statusList: [],
    proposalStatusList: [],
    dealStatusList: [],
    activityStatusList: [],
    invoiceStatusList: [],

};

const getters = {
    getStatus: state => state.statusList,
    getProposalStatus: state => state.proposalStatusList,
    getDealStatus: state => state.dealStatusList,
    getActivityStatus: state => state.activityStatusList,
    getInvoiceStatus: state => state.invoiceStatusList
};
const mutations = {
    STATUS_INFO(state, data) {
        state.statusList = data;
    },
    PROPOSAL_STATUS_INFO(state, data) {
        state.proposalStatusList = data;
    },
    ACTIVITY_STATUS_INFO(state, data) {
        state.activityStatusList = data;
    },
    DEAL_STATUS_INFO(state, data) {
        state.dealStatusList = data
    },
    INVOICE_STATUS_INFO(state, data) {
        state.invoiceStatusList = data
    }
};

const actions = {
    getStatus({commit}) {
        axiosGet(route('statuses.index')).then(response => {
            commit('STATUS_INFO', response.data)
        }).catch((error) => console.log(error));
    },
    getProposalStatus({commit}) {
        axiosGet(route('statuses.index', {_query: {type: "proposal"}})).then(response => {
            commit('PROPOSAL_STATUS_INFO', response.data)
        }).catch((error) => console.log(error));
    },
    getActivityStatus({commit}) {
        axiosGet(route('statuses.index', {_query: {type: "activity"}})).then(response => {
            commit('ACTIVITY_STATUS_INFO', response.data)
        }).catch((error) => console.log(error));
    },
    getDealStatus({commit}) {
        axiosGet(route('statuses.index', {_query: {type: "deal"}})).then(response => {
            commit('DEAL_STATUS_INFO', response.data)
        }).catch((error) => console.log(error));
    },
    getInvoiceStatus({commit}) {
        axiosGet(route('statuses.index', {_query: {type: "invoice"}})).then(response => {
            commit('INVOICE_STATUS_INFO', response.data)
        }).catch((error) => console.log(error));
    },
};


export default {
    state,
    getters,
    actions,
    mutations
}
