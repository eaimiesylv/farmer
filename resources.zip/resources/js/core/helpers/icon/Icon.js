export default class Icon {
    static initFeather() {
        const feather = require('feather-icons');
        feather.replace();
    }
}
