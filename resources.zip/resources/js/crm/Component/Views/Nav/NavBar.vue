<template>
  <div class="container-fluid p-0">
     <router-link to="/admin/dashboard">
            <button>Login</button>
      </router-link>
  </div>       
</template>

